# Bastion Hosts Config
Provides access to secure instances via ssh. 
Ssh is routed via an ELB to provide extra security and resilience. 

## Need To Know


## Usage


## Outstanding Questions


## To Do

