#!/bin/bash

exec > >(tee /var/log/user-data.log|logger -t user-data -s 2>/dev/console) 2>&1
echo BEGIN
date '+%Y-%m-%d %H:%M:%S'
echo END

# Install Inspector

mv install install.old
wget https://d1wk0tztpsntt1.cloudfront.net/linux/latest/install
bash install

# Install New Relic Agent

echo "license_key: ${newrelickey}" | sudo tee -a /etc/newrelic-infra.yml
sudo curl -o /etc/yum.repos.d/newrelic-infra.repo https://download.newrelic.com/infrastructure_agent/linux/yum/el/6/x86_64/newrelic-infra.repo
sudo yum -q makecache -y --disablerepo='*' --enablerepo='newrelic-infra'
sudo yum install newrelic-infra -y

# Configure Splunk

pip install ansible 


cat > /tmp/splunkforwarder.yaml <<EOL

#!/usr/bin/ansible-playbook

---
- hosts: all
  become: yes
  vars:
    env: "dev"
    splunk_elb: "${ splunk_elb}"
    splunk_elb_port: "9997"

  tasks:
  - name: Configure splunk inputs.conf
    copy:
      content: |
                [default]
                host = {{ ansible_hostname }}
                [monitor:///var/log]
                disabled = false
                sourcetype = syslog
                index = main
                
                [monitor:///var/log/aws/codedeploy-agent]
                disabled = false
                sourcetype = codedeploy
                index = main
                
                [monitor:///var/log/upstart/amazon-ssm-agent.log]
                disabled = false
                sourcetype = ssm
                index = main
                
                [monitor:///var/log/amazon/ssm]
                disabled = false
                sourcetype = ssm
                index = main

                [monitor:///opt/snaplogic/run/log/jcc.json]
                disabled = false
                sourcetype = json
                index = main
      dest: /opt/splunkforwarder/etc/system/local/inputs.conf
  - name: Configure splunk outputs.conf
    copy:
      content: |
                [tcpout]
                [tcpout:main]
                server = {{ splunk_elb }}:{{ splunk_elb_port }}
                [tcpout-server: {{ splunk_elb }}:{{ splunk_elb_port }}]
      dest: /opt/splunkforwarder/etc/system/local/outputs.conf
  - name: Configure splunk server.conf
    copy:
      content: |
                [general]
                serverName = {{ ansible_hostname }}
      dest: /opt/splunkforwarder/etc/system/local/server.conf
  - name: Accept Splunk license
    command: /opt/splunkforwarder/bin/splunk restart
  - name: Enable splunk at boot
    command: /opt/splunkforwarder/bin/splunk enable boot-start

EOL

sudo /usr/local/bin/ansible-playbook -i "localhost," -c local /tmp/splunkforwarder.yaml


# Add DNA team keys to ec2-user
useradd bastion
mkdir /home/bastion/.ssh
chmod 700 /home/bastion/.ssh
cat >> /home/bastion/.ssh/authorized_keys <<EOL
ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEAld2WLyToB+0/DOHur7zDL1gsTKv4hYiffxB3uaCIcVtpEJoovnksk7woobECC47M5ed8GXsUbIoBvT+R5NSeWcUAu6jxjGLCh6kbz/tnWqchJga7VrYJT/RtUGaie8jaBcZIbw3TMNe1LGJVtK/tWYiRVkfPZBBjxhP/q0y/HmpiAyb1kuakfL6KXulhWn11PMhpvX036kvhpXdnWJmWrI6UlCe4DDPfHyQhFOXc5P4LZo9UeibYO8T1Y8cOabUBK8AmHCE5SQERj60w7n5rAbqab4rnLYYF74+c3E0x2wbl09tPhXcqMdW9RbNj01Xx38rCyN3U5v/QKKhbWhrWBQ== neeti
ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEAmfcRRNvfN6nC/tcl4xFbBk1SVSjLXlk0PbfEpC3HnurEKpOoGz5ug5SKHVZIBB2m/J9vWQDnCp6vMQxM4/cq86jHXRzvQWmJuZzVAaAuY9Mc/yJU+CUUQWNE+9FQpIvGkgiKdffokyj2Ze4hn/gStx9Iy+l5xle98M/y3xX/gjd1Cd4n0P+lBVgZ/RUdn4zbuwH/aOOXcotXpT9UYh4Dtr5Q+mZW2E+a1oTaPCTXqhHkylCmZ7b0xDQ3kTF34EGV2DUVVx6A5hMwhNjslJZJA6PRyjKbB1Uk1ANgxlsRS0IidbWcgiHzdGJzlBVYJtqHQBx4suv2WbpwtoPvpQp9PQ== abhi
ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEA4K0NctsbI0LIcy5BnFdho3xO1A0QP9PLZ8xtDO6wkKBmRaPEKFCWcQ/vSsTuWDwPoLH4TFXg8QBcE6i9YpqcSjZ+AkFxbxdi/tJfmtcDQmrRC4ajZECWtpadTlzWBY7PiZletiw8nbI4conIj3wAkrGuT06hR5z3AqsKC95RXbZ6tEpoGCIPgaK1D5WxgMLhrjEKsLAsuENSB23oWaScyntzV8XW/rX1XTwAhlkMhB0CNPeUE68edJ+SAtl8QJDyFz8Evly+zFXbgaF78BRDW2BbpScsbfXgCyMYaJRKABF2DKjB8smGewCeBniSBPrl0jIAPedBCZPsfScpQ+rPlQ== yogi
ssh-rsa AAAAB3NzaC1yc2EAAAABJQAAAQEAg1Ankewd9KdlVmE5ZtBUjYT4W0fRMMxelKGeFGk3nKO3JvzZgyp9C061KSsUCzE1E0U6N9LYCxv30wa7EdXJGwOLtY9bIu+tWN6iJC4pDDCv0Gid0FHrLiUOebXoo6MSJ8d8Ki8Znc1D4gSrRflCekAs33bZksVDyhNYt5GZzAQowxvLTPW+gae/bbbzmivXU1IIlfXjG7IbZ6ylbkIDWEwfg3CQ8LDEQJKphZwjxes59Untq2H5JuhhBRfPkaKYorQuKyxKbN/s6CvHHJcuiRVmAvAtRCfXKE3xqF3d7FOQzl7iJUpRnAEQkZ5K9ttJGNq/OK39Mesz9QfeyzKSJQ== shivam
ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDAsr8M7+WRdhG2lJPb4XQitnVgK1O2j20AxSPfivL40PIUFqVS0eArLA/Qo8nieeYBFG6zD5iQrQRaOG/MR/7zOVujvTmtnzMRgvq8+OiNj1cp7Lfx2afbSe0UXIPPP5EzeVxapmzSCh9CmLglnE02quYptowaRZ0NXpIuVkbEHas0SlAEE2ljm5cZ1b6bfB9GBdVTalDFXGPcRZRfettrWKbpWj+itllzc4Q0W2vg+h93LBXcikZtB46v4fUIn9xUA4r1iOjq7Cj/kjxvC4Xblio5o+4OAYUBbJPL2kUFp83CWMwg3yUiwnErl9X+FX2vAIii0zrvZzPwwfWptvnP Lukas Korous@PRA000186871001
EOL
chmod 600 /home/bastion/.ssh/authorized_keys
chown -R bastion.bastion /home/bastion/.ssh
