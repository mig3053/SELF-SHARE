#!/usr/bin/env bash

# Crawls each region looking for a default VPC and if found, detaches the IGW and deletes both
# Requires aws cli and jq to be installed



function error_and_die {
  echo -e "ERROR: ${1}" >&2;
  exit 1;
};


iam_caller_id="$(aws sts get-caller-identity --query 'Arn' --output text)";
if [ -n "${iam_caller_id}" ]; then
  echo -e "AWS Credentials Found. Using ARN '${iam_caller_id}'";
else
  error_and_die "No AWS Credentials Found. \"aws sts get-caller-identity --query 'Arn' --output text\" responded with ARN '${iam_caller_id}'";
fi;

aws_account_alias="$(aws iam list-account-aliases --output text  --query 'AccountAliases')";
if [ -n "${aws_account_alias}" ]; then
  echo -e "AWS Account Alias: ${aws_account_alias}";
fi;

read -p "Are you sure you wish to delete all default VPCs for this account? " -n 1 -r
echo    # (optional) move to a new line
if [[ $REPLY =~ ^[Yy]$ ]]
then

for region in $(aws ec2 describe-regions --region eu-west-1 | jq -r .Regions[].RegionName); do

  echo "* Region ${region}"

  # get default vpc
  vpc=$(aws ec2 --region ${region} \
    describe-vpcs --filter Name=isDefault,Values=true \
    | jq -r .Vpcs[0].VpcId)
  if [ "${vpc}" = "null" ]; then
    echo "No default vpc found"
    continue
  fi
  echo "Found default vpc ${vpc}"

  # get internet gateway
  igw=$(aws ec2 --region ${region} \
    describe-internet-gateways --filter Name=attachment.vpc-id,Values=${vpc} \
    | jq -r .InternetGateways[0].InternetGatewayId)
  if [ "${igw}" != "null" ]; then
    echo "Detaching and deleting internet gateway ${igw}"
    aws ec2 --region ${region} \
      detach-internet-gateway --internet-gateway-id ${igw} --vpc-id ${vpc}
    aws ec2 --region ${region} \
      delete-internet-gateway --internet-gateway-id ${igw}
  fi

  # get subnets
  subnets=$(aws ec2 --region ${region} \
    describe-subnets --filters Name=vpc-id,Values=${vpc} \
    | jq -r .Subnets[].SubnetId)
  if [ "${subnets}" != "null" ]; then
    for subnet in ${subnets}; do
      echo "Deleting subnet ${subnet}"
      aws ec2 --region ${region} \
        delete-subnet --subnet-id ${subnet}
    done
  fi


  # https://docs.aws.amazon.com/cli/latest/reference/ec2/delete-vpc.html
  # - You can't delete the main route table
  # - You can't delete the default network acl
  # - You can't delete the default security group

  # delete default vpc
  echo "Deleting vpc ${vpc}"
  aws ec2 --region ${region} \
    delete-vpc --vpc-id ${vpc}

done

fi