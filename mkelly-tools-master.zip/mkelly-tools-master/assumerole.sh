#!/bin/bash

# This script assumes using aws-vault to store your keys in the mac keychain
# https://github.com/99designs/aws-vault/blob/master/README.md
# Create profiles for shared-npn and 

# https://medium.com/faun/step-by-step-aws-iam-assumerole-with-aws-vault-configuration-9d5986373c33


read -p "Enter account: " ACCOUNT

# Once we know the account, and assuming we will use the admin role, we can figure out 
# * Does it use the ndm-shared-npn or ndm-shared profile
# * whether it uses the ndm-shared or ndm-shared-npn account number in the MFA arn later
# * What the ARN for the account will be to determine the assumed role arn later


case $ACCOUNT in
    ndm-pop-npn)
        ACCOUNTID=575943265475
        SHARED_ACCOUNTID=389017719203
        PROJECT=pop
        PROFILE=shared-npn
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-pop)
        ACCOUNTID=938706516612
        SHARED_ACCOUNTID=436441654523
        PROJECT=pop
        PROFILE=shared
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-taz-npn)
        ACCOUNTID=074475680064
        SHARED_ACCOUNTID=389017719203
        PROFILE=shared-npn
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-cls-npn)
        ACCOUNTID=846173432943
        SHARED_ACCOUNTID=389017719203
        PROJECT=cls
        PROFILE=shared-npn
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-cls)
        ACCOUNTID=793955643365
        SHARED_ACCOUNTID=436441654523
        PROJECT=cls
        PROFILE=shared
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-cms-npn)
        ACCOUNTID=776769991642
        SHARED_ACCOUNTID=389017719203
        PROFILE=shared-npn
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-cms)
        ACCOUNTID=437932939215
        SHARED_ACCOUNTID=436441654523
        PROFILE=shared
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-rede-npn)
        ACCOUNTID=661889448657
        SHARED_ACCOUNTID=389017719203
        PROJECT=rede
        PROFILE=shared-npn
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    ndm-rede)
        ACCOUNTID=579608238019
        SHARED_ACCOUNTID=436441654523
        PROJECT=rede
        PROFILE=shared
        REGION="us-east-1"
        ROLE="arn:aws:iam::$ACCOUNTID:role/"$PROJECT"_role_admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin_kelly@external.mckinsey.com
        ;;
    mkelly-aws1)
        ACCOUNTID=052188317850
        SHARED_ACCOUNTID=052188317850
        PROFILE=default
        REGION="us-west-2"
        ROLE="arn:aws:iam::$ACCOUNTID:role/local-admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin.kelly
        ;;
    mkelly-aws2)
        ACCOUNTID=501265705227
        SHARED_ACCOUNTID=052188317850
        PROFILE=default
        REGION="us-west-2"
        ROLE=arn:aws:iam::$ACCOUNTID:role/"$ACCOUNT-role-techops"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin.kelly
        ;;
    mkelly-aws3)
        ACCOUNTID=745702112939
        SHARED_ACCOUNTID=052188317850
        PROFILE=default
        REGION="us-west-2"
        ROLE=arn:aws:iam::$ACCOUNTID:role/"$ACCOUNT-admin"
        DEVICE_SERIAL=arn:aws:iam::$SHARED_ACCOUNTID:mfa/martin.kelly
        ;;
    *)
        echo "Invalid account alias"
        ;;
esac

# Debug spam
echo "MFA device is $DEVICE_SERIAL"
echo "ROLE is $ROLE"

read -p "Enter MFA Code: " TOKEN_CODE


session=$(aws-vault exec $PROFILE -- aws sts assume-role --role-arn "$ROLE" --role-session-name=$HOSTNAME.$$ --serial-number "$DEVICE_SERIAL" --token-code "$TOKEN_CODE"| jq -r '.Credentials | @sh "export AWS_ACCESS_KEY_ID=\(.AccessKeyId) AWS_SECRET_ACCESS_KEY=\(.SecretAccessKey) AWS_SESSION_TOKEN=\(.SessionToken)"')
if [ -z "$session" ]; then
  echo >&2 "Failed to get credentials for $role!"
  exit 2
fi

eval $session
if [ $# -gt 0 ]; then
  exec ${1+"$@"}
else
  # We export the account for the prompt then fire up a new shell so our exports stick, otherwise they are lost when this script dies.  
  export account=$ACCOUNT
  export AWS_DEFAULT_REGION=$REGION
  exec /bin/bash -il
fi

