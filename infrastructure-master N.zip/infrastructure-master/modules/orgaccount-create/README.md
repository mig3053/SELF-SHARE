### What this module does

* Creates a subsidiary org account and role, and exports the details in state for consumption by the bootstrap component