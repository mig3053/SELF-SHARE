!/usr/bin/env bash

touch /var/tmp/ksm

## Bit hacky - ansible playbook or something here would be good..
cat <<"EOF" >> /home/ec2-user/.ssh/authorized_keys

EOF


account=$(curl -s http://169.254.169.254/latest/dynamic/instance-identity/document | grep -oP '(?<="accountId" : ")[^"]*(?=")')
wget https://ndm-shared-common.s3.amazonaws.com/nessus/agents/nessus-agent-aws.rpm
sudo rpm -ivh nessus-agent-aws.rpm
sudo /sbin/service nessusagent start
sudo /opt/nessus_agent/sbin/nessuscli agent link --key=de0afbd6c0a12ce2a147bbd5b4114d2dacbb5ec0486c02e9fa13b9e3691025f5 --groups="$account" --cloud



