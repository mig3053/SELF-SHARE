# Numapp Component 
Creates following for Staging env. 

Bastion Host
App Server
RDS 
ELB 
Security Groups

