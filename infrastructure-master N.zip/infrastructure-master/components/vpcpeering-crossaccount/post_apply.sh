#!/bin/bash
# This manually run the commands to associate domains with vpcs cross account


#aws route53 create-vpc-association-authorization --hosted-zone-id Z2FWKPMOJ8KV9F --vpc VPCRegion=eu-west-1,VPCId=vpc-2ecf1649


#aws route53 associate-vpc-with-hosted-zone --hosted-zone-id Z2FWKPMOJ8KV9F --vpc VPCRegion=eu-west-1,VPCId=vpc-2ecf1649