# Terraform SSM Module

### Before apply:
* udpate variables in `terraform.tfvars` and `tf_modules/ssm_patch/terraform.tfvars`
* follow procedure in [Box manual](https://mckinsey.box.com/s/ehcz3p1u56mb14rj32ybq8b1mct6yg4l)

### Bugs:
* [Resolved] aws_ssm_patch_baseline operating_system CENTOS missing:  https://github.com/terraform-providers/terraform-provider-aws/issues/4170
* add support for setting default SSM patch baseline:  https://github.com/terraform-providers/terraform-provider-aws/issues/3342
