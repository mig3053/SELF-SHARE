import boto3
import json
import logging

log = logging.getLogger()
log.setLevel(logging.INFO)

def evaluate_compliance(configuration_item):
    inspector = boto3.client('inspector')
    list_assessment_targets = inspector.list_assessment_targets()
    target_arn_list = []
    instances_list = []
    agents_list = []
    is_healthy = ""

    for i in list_assessment_targets['assessmentTargetArns']:
        target_arn_list.append(i)

    for i in target_arn_list:
        agents_list.append(inspector.preview_agents(
            previewAgentsArn=i,
            maxResults=500
        ))

    for i in agents_list:
        instances_list.append(i['agentPreviews'])

    for sublist in agents_list:
        for i in sublist['agentPreviews']:
            if  configuration_item['configurationItemStatus'] == 'ResourceDeleted':
                log.info('Instance %s is marked as deleted', configuration_item['resourceId'])
                is_healthy = "deleted"
            elif i['agentId'] == configuration_item['resourceId'] and i['agentHealth'] != 'HEALTHY':
                log.info(i['agentId'] + ' ' + i['agentHealth'])
                is_healthy = False
            elif i['agentId'] == configuration_item['resourceId'] and i['agentHealth'] == 'HEALTHY':
                log.info(i['agentId'] + ' ' + i['agentHealth'])
                is_healthy = True
            else:
                log.error('Instance %s not in target groups', configuration_item['resourceId'])

    if is_healthy:
        log.info("COMPLIANT")
        return {
            "compliance_type": "COMPLIANT",
            "annotation": 'Inspector agent healthy'
        }
    if is_healthy == "deleted":
        log.info("NON APPLICABLE")
        return {
            "compliance_type": "NOT_APPLICABLE",
            "annotation": 'Resource Deleted, setting Compliance Status to NOT_APPLICABLE.'
        }
    else:
        log.info("NON COMPLIANT")
        return {
            "compliance_type" : "NON_COMPLIANT",
            "annotation" : 'Inspector agent unhealthy'
        }


def lambda_handler(event, context):
    log.info('Event %s', event)
    invoking_event = json.loads(event['invokingEvent'])
    configuration_item = invoking_event["configurationItem"]
    evaluation = evaluate_compliance(configuration_item)
    config = boto3.client('config')

    response = config.put_evaluations(
        Evaluations=[
            {
                'ComplianceResourceType': invoking_event['configurationItem']['resourceType'],
                'ComplianceResourceId': invoking_event['configurationItem']['resourceId'],
                'ComplianceType': evaluation["compliance_type"],
                "Annotation": evaluation["annotation"],
                'OrderingTimestamp': invoking_event['configurationItem']['configurationItemCaptureTime']
            },
        ],
        ResultToken=event['resultToken'])

