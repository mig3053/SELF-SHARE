from datetime import datetime
import json
import logging
import boto3

log = logging.getLogger()
log.setLevel(logging.INFO)

def put_evaluations(instance_id, compliance_status, annotation, result_token):
    config = boto3.client('config')
    today = datetime.today()
    response = config.put_evaluations(
        Evaluations=[
            {
                'ComplianceResourceType': 'AWS::EC2::Instance',
                'ComplianceResourceId': instance_id,
                'ComplianceType': compliance_status,
                "Annotation": annotation,
                'OrderingTimestamp': datetime(today.year, today.month, today.day, today.hour)
            },
        ],
        ResultToken=result_token)

def lambda_handler(event, context):
    log.info('Event %s', event)
    invoking_event = json.loads(event['invokingEvent'])


    inspector = boto3.client('inspector')
    list_assessment_targets = inspector.list_assessment_targets()
    target_arn_list = []
    instances_list = []
    agents_list = []

    for i in list_assessment_targets['assessmentTargetArns']:
        target_arn_list.append(i)

    for i in target_arn_list:
        agents_list.append(inspector.preview_agents(
            previewAgentsArn=i,
            maxResults=500
        ))

    for i in agents_list:
        instances_list.append(i['agentPreviews'])

    for sublist in agents_list:
        for i in sublist['agentPreviews']:
            if i['agentId'] and i['agentHealth'] != 'HEALTHY':
                log.info(i['agentId'] + ' ' + i['agentHealth'])
                put_evaluations(i['agentId'], "NON_COMPLIANT", "Inspector agent unhealthy", event['resultToken'])
            elif i['agentId'] and i['agentHealth'] == 'HEALTHY':
                log.info(i['agentId'] + ' ' + i['agentHealth'])
                put_evaluations(i['agentId'], "COMPLIANT", "Inspector agent healthy", event['resultToken'])
            else:
                log.error('Instance %s not in target groups', i['agentId'])
