# AWS Config module

This component creates AWS config recorder and several AWS Config rules

## Rules

| Name                   | Description                                                                                   |
| -----------------------| ----------------------------------------------------------------------------------------------|
| ami-rules.tf           | Checks that only specific AMI's are used in EC2                                               |
| s3-rules.tf            | Checks that all S3 buckets are using a specific KMS key for encryption                        |
| public-subnet-rules.tf | Checks that no EC2 instance runs in a public subnet by checking if there is a route to an IGW |

## Inputs

| Name                            | Description                                          | Default  | Required |
|---------------------------------|------------------------------------------------------|:--------:|:--------:|
| aws_region                      | Region where to deploy AWS Config                    | -        | yes      |
| env                             | Environment Name                                     | -        | yes      |
| project                         | Name of the project for the deployment               | -        | yes      |
| project_longname                | Full Name of the project for the deployment          | -        | yes      |
| kms_key_arn                     | KMS key used for encrypting S3 buckets               | -        | yes      |
| approved_amis_list              | List of compliant AMI's separated by commas          | `<list>` | yes      |

## Outputs

None
