1) Setup  cli connectivity to aws  "ndm-num" account.

2) Clone  the repo to Desktop

3) cd infrastructure/etc/

4) Edit the env_us-east-1_dump.tfvars file and change line #10 
   today="072720" to current date.
   
5) cd  infrastructure/bin

6)  ./scaffold.sh -e dump -p num -c maskeddb -r us-east-1 -a <plan/apply>
   
   This code does the following 
    a) Create snapshot of current PROD Database. 
    b) Spin up DB instance from newly created snapshot 
 
 7) Above  step will take ~25-30mins  and after completion.
 
 8) Connect Bastion host via SSM
 
 9) Copy SQL scripts 
    cd /var/tmp ;  
    aws s3 sync s3://num-db-dump/sql/ .  ; 
    
    modify "create-maskeddb-dump.sql"  and "upload-file-s3.sql" with name of dump file to be created and uploaded.
    
 10) Setup SQLplus  connectivity
     a) sqlplus sa/<PASSWORD>@nmsprd-<DATE USED in STEP 4>.czvwkkk9sdrt.us-east-1.rds.amazonaws.com:1521/nmsprd  
 
11) Take  a masked DUMP 
     a) sqlplus sa/<PASSWORD>@nmsprd-<DATE USED in STEP 4>.czvwkkk9sdrt.us-east-1.rds.amazonaws.com:1521/nmsprd  < create-maskeddb-dump.sql 
     This should take 10mins
                                                                                                                                           
 12)    Once completed upload file to s3://num-db-dump/ bucket 
        a) sqlplus sa/<PASSWORD>@nmsprd-<DATE USED in STEP 4>.czvwkkk9sdrt.us-east-1.rds.amazonaws.com:1521/nmsprd  < upload-file-s3.sql

13) Verify upload and download  file tio desktop. Zip it and share via Box Folder.
                                                                                                                                        
 
