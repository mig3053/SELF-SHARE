# AWS Inspector

This Terraform templates will configure assessments rules, targets, schedules for security/vulnerability scans by using AWS Inpector capabilities.

## Internel How-To

* [How to configure AWS Inspector] -> work in progress

### Content
```
main.tf
```
Main Terraform template which is configuring assessment groups, templates and targets to be used in the vulnerability scanning.

```
iam.tf
```
Creates IAM role for CloudWatch which will trigger the assessment run.

```
cloudwatch.tf
```
Creates CloudWatch rule which includes when to run assessments.

```
vars.tf
```
Contains per AWS region rule assessment packages, duration of assessment run, instances common tag, assessment schedule, solution name and type

## Important
Assessment rules ARNs are different per regions.
