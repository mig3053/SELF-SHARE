# Bootstrap terraform for scaffold

* Creates buckets with secure configuration for state and logs
* Creates a dynamodb table for state locking